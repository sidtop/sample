package com.example.simple.logindemo;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.FrameLayout;

public class NewSampleActivity extends AppCompatActivity {

    private BottomNavigationView mMainNav;
    private FrameLayout mMainFrame;
    private LocationFragment locationFragment;
    private CameraFragment cameraFragment;
    private NotesFragment notesFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsample);
        locationFragment = new LocationFragment();
        cameraFragment = new CameraFragment();
        notesFragment = new NotesFragment();
        setFragment(locationFragment);
        mMainNav = (BottomNavigationView)findViewById(R.id.main_nav);
        mMainFrame = (FrameLayout)findViewById(R.id.main_frame);
        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_loc:
                            mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                            setFragment(locationFragment);
                            return true;

                        case R.id.nav_cam:
                            mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                            setFragment(cameraFragment);
                            return true;

                        case R.id.nav_notes:
                            mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                            setFragment(notesFragment);
                            return true;
                        default:
                            return false;
                    }

                }
        });

    }

    private void setFragment(Fragment fragment) {
        android.support.v4.app.FragmentTransaction fT = getSupportFragmentManager().beginTransaction();
        fT.replace(R.id.main_frame,fragment);
        fT.commit();

    }
}

